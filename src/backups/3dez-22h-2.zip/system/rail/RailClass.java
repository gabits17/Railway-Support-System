package system.rail;

import dataStructures.*;
import system.time.ScheduleEntry;
import system.station.Station;
import system.station.StationClass;
import system.time.Time;
import system.time.TimeClass;
import system.train.Train;
import system.train.TrainClass;

public class RailClass implements RailGet, Rail {
    /**
     * Serial Version UID of the Class
     */
    static final long serialVersionUID = 0L;

    /**
     * Name of the rail.
     */
    private final String name;

    /**
     * Set of stations that belong to the rail.
     */
    private final SearchableDoubleList<Station> stations;

    private OrderedDictionary<Time,Train> trainsDir1;
    private OrderedDictionary<Time,Train> trainsDir2;
    private List<Train> allTrains;
    /**
     * Terminal stations.
     */
    private Station term1, term2;

    /**
     * Constructor of an entity Rail.
     * @param name Name of the rail.
     */
    public RailClass(String name) {
        this.name = name;
        term1 = term2 = null;
        trainsDir1 = new AVLTree<>();
        trainsDir2 = new AVLTree<>();
        allTrains = new DoubleList<>();
        stations = new SearchableDoubleListClass<>();
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int numberOfStations() {
        return stations.size();
    }

    @Override
    public void insertStation(Station station) {
        stations.addLast(station);
    }

    @Override
    public TwoWayIterator<Station> listStations() {
        return stations.twoWayIterator();
    }

    @Override
    public void setTerminals() {
        term1 = stations.get(0);
        term2 = stations.get(numberOfStations() - 1);
    }

    @Override
    public Station getTerminal1() {
        return term1;
    }

    @Override
    public Station getTerminal2() {
        return term2;
    }
    
    @Override
    public void insertTrain(List<ScheduleEntry> entries, int train) {
        Train t = new TrainClass(entries,train);
        ScheduleEntry dep = entries.get(0);
        Time depTime = dep.time();
        if(dep.station().getName().equalsIgnoreCase(term1.getName())) trainsDir1.insert(depTime, t);
        else trainsDir2.insert(depTime, t);
        insertTrainInStations(entries,t);
        allTrains.addLast(t);
    }

    private void insertTrainInStations(List<ScheduleEntry> entries, Train train) {
        Iterator<ScheduleEntry> it = entries.iterator();
        while(it.hasNext()) {
            ScheduleEntry entry = it.next();
            Station s = entry.station();
            s.insertTrain(entry.time(),train);
        }
    }

    @Override
    public void removeTrain(String station, String hour, String minute) {
        Time time = new TimeClass(hour,minute);
        Train t;
        if(station.equalsIgnoreCase(term1.getName())) {
            t = trainsDir1.find(time); // Time é único num sentido e numa linha
            trainsDir1.remove(time);
        }
        else {
            t = trainsDir2.find(time);
            trainsDir2.remove(time);
        }
        removeTrainFromStations(time,t);
        allTrains.remove(t);
    }

    private void removeTrainFromStations(Time t, Train tr) {
        Iterator<Station> it = stations.iterator();
        while (it.hasNext()) {
            Station s = it.next();
            s.removeTrain(t, tr.getNumber());
        }
    }

    @Override
    public Iterator<Train> listTrainsDepartingAt(Station dep) {
        Iterator<Entry<Time,Train>> it;
        if(dep.getName().equalsIgnoreCase(term1.getName())) it = trainsDir1.iterator();
        else it = trainsDir2.iterator();

        return new VIterator<>(it);
    }

    @Override
    public boolean isTerminal(Station s) {
        return s.equals(term1) || s.equals(term2);
    }

    @Override
    public Train getBestSchedule(String dep, String arrv, String hour, String min) {
        Station departure = getStation(dep);
        Station arrival = getStation(arrv);
        boolean direction = findDirection(departure,arrival);
        Iterator<Entry<Time,Train>> it;
        if(direction) it = trainsDir1.iterator();
        else it = trainsDir2.iterator();
        Time expect = new TimeClass(hour,min);
        Time best = null;
        Train bestSch = null;

        while(it.hasNext()) {
            Train t = it.next().getValue();
            Iterator<ScheduleEntry> schIt = t.listScheduleEntries();
            boolean found = findDeparture(schIt,departure);
            if(found) {
                while(schIt.hasNext()) {
                    ScheduleEntry p = schIt.next();
                    Time time = p.time();
                    Station st = p.station();
                    if (st.equals(arrival)) {
                        if ((time.compareTo(expect) <= 0) && (best == null || time.compareTo(best) > 0)) {
                                best = time; bestSch = t;
                       }
                    }
                }
            }
        }
        return bestSch;
    }

    // Retorna true se o sentido for o normal; false caso contrário.
    private boolean findDirection(Station departure, Station arrival) {
        int dep_idx = stations.find(departure);
        int arr_idx = stations.find(arrival);
        return dep_idx < arr_idx;
    }

    @Override
    public Train findSchedule(String dep, String hour, String min) {
        int h = Integer.parseInt(hour);
        int m = Integer.parseInt(min);
        Station departure = getStation(dep);
        Iterator<Entry<Time,Train>> it;
        if(departure.equals(term1)) it = trainsDir1.iterator();
        else it = trainsDir2.iterator();
        while(it.hasNext()) {
            Entry<Time,Train> e = it.next();
            Time time = e.getKey();
            Train t = e.getValue();
            if(t.getDepartureStation().equals(departure) && h == time.getHour() && m == time.getMin())
                return t;
        }
        return null;
    }

    @Override
    public Station getStation(String name) {
        Station s = new StationClass(name);
        return stations.findEquals(s);
    }

    @Override
    public void removesAllTrainsFromStations() {
        Iterator<Train> it = allTrains.iterator();
        while(it.hasNext()) {
            Train train = it.next();
            Iterator<ScheduleEntry> schIt = train.listScheduleEntries();
            while (schIt.hasNext()) {
                ScheduleEntry p = schIt.next();
                Station s = p.station();
                Time t = p.time();
                s.removeTrain(t,train.getNumber());
            }
        }
    }

    /***** PRIVATE METHODS *****

    /**
     * Finds the departure station of the route that was given.
     * Auxiliary method to implement the MH command.
     * @param entriesIt Iterator of entries of the schedule.
     * @param departure Departure station of the route.
     * @return True if found, false otherwise.
     */
    private boolean findDeparture(Iterator<ScheduleEntry> entriesIt, Station departure) {
        boolean foundDeparture = false;
        while (!foundDeparture && entriesIt.hasNext()) {
            ScheduleEntry ent = entriesIt.next();
            if (ent.station().equals(departure))
                foundDeparture = true;
        }
        return foundDeparture;
    }
}