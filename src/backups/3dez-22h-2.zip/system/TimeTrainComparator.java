package system;

import dataStructures.Comparator;

public class TimeTrainComparator implements Comparator<PassingTrain> {

    @Override
    public int compare(PassingTrain o1, PassingTrain o2) {
        int res = o1.getTime().getHour() - o2.getTime().getHour();
        if (res == 0) res = o1.getTime().getMin() - o2.getTime().getMin();
        if (res == 0) res = o1.getTrain().getNumber() - o2.getTrain().getNumber();
        return res;
    }
}
