package dataStructures;

import dataStructures.exceptions.NoSuchElementException;

public class VIterator<K,V> implements Iterator<V> {

    private final Iterator<Entry<K,V>> it;

    public VIterator(Iterator<Entry<K,V>> it) {
        this.it = it;
    }

    @Override
    public boolean hasNext() {
        return it.hasNext();
    }

    @Override
    public V next() throws NoSuchElementException {
        if(!hasNext()) throw new NoSuchElementException();
        return it.next().getValue();
    }

    @Override
    public void rewind() {
        it.rewind();
    }
}
