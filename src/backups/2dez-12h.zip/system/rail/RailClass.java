package system.rail;

import dataStructures.*;
import system.time.TimeStationPair;
import system.station.Station;
import system.station.StationClass;
import system.time.Time;
import system.time.TimeClass;
import system.train.Train;
import system.train.TrainClass;

public class RailClass implements RailGet, Rail {
    /**
     * Serial Version UID of the Class
     */
    static final long serialVersionUID = 0L;

    /**
     * Name of the rail.
     */
    private final String name;

    /**
     * Set of stations that belong to the rail.
     */
    private final SearchableDoubleList<Station> stations;

    /**
     * Set of trains that contains a schedule through this rail.
     * Ordered by time of departure.
     */
    private final Dictionary<TimeStationPair, Train> trains;

    /**
     * Terminal stations.
     */
    private Station term1, term2;

    /**
     * Constructor of an entity Rail.
     * @param name Name of the rail.
     */
    public RailClass(String name) {
        this.name = name;
        this.stations = new SearchableDoubleListClass<>();
        this.trains = new OrderedDoubleList<>();
        this.term1 = this.term2 = null;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int numberOfStations() {
        return stations.size();
    }

    @Override
    public void insertStation(Station station){
        stations.addLast(station);
    }

    @Override
    public TwoWayIterator<Station> listStations() {
        return stations.twoWayIterator();
    }

    @Override
    public void setTerminals() {
        term1 = stations.get(0);
        term2 = stations.get(numberOfStations() - 1);
    }

    @Override
    public Station getTerminal1() {
        return term1;
    }

    @Override
    public Station getTerminal2() {
        return term2;
    }

    public void removeRailSchedulesFromStations(){
        Iterator<Entry<TimeStationPair,Train>> it = trains.iterator();
        while(it.hasNext()){
            Entry<TimeStationPair, Train> entry= it.next();
            Iterator<TimeStationPair> itTrain= entry.getValue().listScheduleEntries();
            while(itTrain.hasNext()) {
                TimeStationPair train = itTrain.next();
                Station s = train.getStation();
                Time t = train.getTime();
                s.removeTrain(t, entry.getValue().getNumber());
            }
        }
    }

    @Override
    public void insertTrain(List<TimeStationPair> entries, int train) {
        Train t = new TrainClass(entries,train);
        TimeStationPair terminal1 = entries.get(0);
        trains.insert(terminal1,t);

        Iterator<TimeStationPair> it = entries.iterator();
        while(it.hasNext()) {
            TimeStationPair pair = it.next();
            Station s = pair.getStation();
            Time time = pair.getTime();
            s.insertTrain(time,t);
        }
    }

    @Override
    public void removeTrain(String station, String hour, String minute)  {
        TimeStationPair e = findEntry(station,hour,minute);
        int trainNr= trains.find(e).getNumber();
        Iterator<TimeStationPair>it = trains.find(e).listScheduleEntries();
        while(it.hasNext()){
            TimeStationPair t = it.next();
            Station s = t.getStation();
            s.removeTrain(t.getTime(), trainNr);
        }
        trains.remove(e);
    }

    @Override
    public Iterator<Train> consultTrainsScheduleDepartingAt(Station station) {
        List<Train> departSchedules = new DoubleList<>();
        Iterator<Entry<TimeStationPair, Train>> it = trains.iterator();
        while (it.hasNext()) {
            Entry<TimeStationPair, Train> e = it.next();
            Station s = e.getKey().getStation();
            if (s.equals(station))
                departSchedules.addLast(e.getValue());
        }
        return departSchedules.iterator();
    }

    @Override
    public boolean isTerminal(Station s) {
        return s.equals(term1) || s.equals(term2);
    }

    @Override
    public Train getBestSchedule(String dep, String arrv, String hour, String min) {
        Station arrival = getStation(arrv);
        Station departure = getStation(dep);
        Time expect = new TimeClass(hour,min);
        Time best = null;
        Train bestSch = null;

        Iterator<Entry<TimeStationPair, Train>> trainsIt = trains.iterator();
        while(trainsIt.hasNext()) {
            Train sch = trainsIt.next().getValue();
            Iterator<TimeStationPair> entriesIt = sch.listScheduleEntries();
            boolean found = findDeparture(entriesIt,departure);
            if (found) {
                while (entriesIt.hasNext()) {
                    TimeStationPair ent = entriesIt.next();
                    Time time = ent.getTime();
                    Station st = ent.getStation();

                    if (st.equals(arrival)) {
                        if ((time.compareTo(expect) <= 0) && (best == null || time.compareTo(best) > 0)) {
                                best = time; bestSch = sch;
                        }
                    }
                }
            }
        }
        return bestSch;
    }

    @Override
    public TimeStationPair findEntry(String station, String hour, String min) {
        int h = Integer.parseInt(hour);
        int m = Integer.parseInt(min);
        Iterator<Entry<TimeStationPair, Train>> it = trains.iterator();
        while(it.hasNext()) {
            TimeStationPair entry = it.next().getKey();
            Time t = entry.getTime();
            if(entry.getStation().getName().equalsIgnoreCase(station) &&
                    h == t.getHour() && m == t.getMin())
                return entry;
        }
        return null;
    }

    @Override
    public Station getStation(String name) {
        Station s = new StationClass(name);
        return stations.findEquals(s);
    }

    /***** PRIVATE METHODS *****

    /**
     * Finds the departure station of the route that was given.
     * Auxiliary method to implement the MH command.
     * @param entriesIt Iterator of entries of the schedule.
     * @param departure Departure station of the route.
     * @return True if found, false otherwise.
     */
    private boolean findDeparture(Iterator<TimeStationPair> entriesIt, Station departure) {
        boolean foundDeparture = false;
        while (!foundDeparture && entriesIt.hasNext()) {
            TimeStationPair ent = entriesIt.next();
            if (ent.getStation().equals(departure))
                foundDeparture = true;
        }
        return foundDeparture;
    }
}