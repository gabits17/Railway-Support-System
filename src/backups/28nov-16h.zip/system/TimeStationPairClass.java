package system;

import system.station.Station;
import system.time.Time;

public class TimeStationPairClass implements TimeStationPair{
    private final Station station;
    private final Time time;

    /**
     * Constructor of a pair Time-Station, aka schedule entry.
     * @param station Station associated.
     * @param time Time associated.
     */
    public TimeStationPairClass(Station station, Time time) {
        this.station = station;
        this.time = time;
    }

    @Override
    public Station getStation() {
        return station;
    }

    @Override
    public Time getTime() {
        return time;
    }

    public int compareTo(TimeStationPair o) {
        int res = time.compareTo(o.getTime());
        if (res == 0) res = station.getName().compareTo(o.getStation().getName());
        return res;
    }
}
