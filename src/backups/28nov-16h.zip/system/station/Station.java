package system.station;

import dataStructures.Entry;
import dataStructures.Iterator;
import system.rail.Rail;
import system.time.Time;

/**
 * Deals with the modifications of the entity Station.
 * @author Gabriela Silva (67286) gt.silva@campus.fct.unlt.pt
 * @author Clara DIas (67215) cso.dias@campus.fct.unl.pt
 */
public interface Station extends StationGet {

    void insertTrain(int train, Time time);

    /**
     * Inserts rail <r> to station.
     * It means the station belongs to that rail.
     * @param r Rail being inserted.
     */
    void insertRail(Rail r);

    /**
     * Removes rail <r> from the station.
     * It means the rail was removed from the system.
     * @param r Rail being removed.
     */
    void removeRail(Rail r);

    Iterator<Rail> listRails();

    Iterator<Entry<Time, Integer>> listTrains();
}
