package dataStructures.exceptions;

import java.io.Serial;

public class EmptyQueueException extends RuntimeException{
    /**
     * Serial Version UID of the Class
     */
    @Serial
    private static final long serialVersionUID = 0L;
}
