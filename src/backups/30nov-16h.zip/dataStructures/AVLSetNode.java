package dataStructures;

public class AVLSetNode<E extends Comparable<E>> extends BSTNode<E> {

    /**
     * Serial Version UID of the Class.
     */
    static final long serialVersionUID = 0L;

    /**
     * 'E': height(node.getLeft()) = height(node.getRight());
     * 'L': height(node.getLeft()) = height(node.getRight()) + 1;
     * 'R': height(node.getLeft()) = height(node.getRight()) - 1.
     */
    private char balance;

    public AVLSetNode(E elem, char balance, BSTNode<E> parent, BSTNode<E> left, BSTNode<E> right) {
        super(elem, parent, left, right);
        this.balance = balance;
    }

    public AVLSetNode(E elem) {
        super(elem);
    }

    public char getBalance() {
        return balance;
    }

    public void setBalance(char balance) {
        this.balance = balance;
    }
}
