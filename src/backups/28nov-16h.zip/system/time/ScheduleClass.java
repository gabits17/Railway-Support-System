package system.time;

import dataStructures.*;
import system.TimeStationPair;

public class ScheduleClass implements Schedule {
    /**
     * Serial Version UID of the Class
     */
    static final long serialVersionUID = 0L;

    /**
     * Number of the train that goes through this schedule
     */
    private final int train;

    /**
     * Schedule entries.
     */
    private final List<TimeStationPair> timetableEntries;

    public ScheduleClass(List<TimeStationPair> entries , int train) {
        this.train = train;
        timetableEntries = new DoubleList<>();
        fillEntries(entries);
    }

    /**
     * Fills the list with entries (station-time pair) of the schedule.
     * @param entries Entries of the schedule.
     */
    private void fillEntries(List<TimeStationPair> entries) {
        for(int i = 0; i < entries.size(); i++)
            timetableEntries.addLast(entries.get(i));
    }

    @Override
    public int getTrainNumber() {
        return train;
    }

    @Override
    public Iterator<TimeStationPair> listEntries() {
        return timetableEntries.iterator();
    }
}
