package dataStructures;

/**
 * AVL tree implementation
 *
 * @author AED team
 * @version 1.0
 *
 * @param <K> Generic type Key, must extend comparable
 * @param <V> Generic type Value 
 */
public class AVLTree<K extends Comparable<K>, V>
        extends AdvancedBSTree<K,V> implements OrderedDictionary<K,V> {

    AVLTree(AVLNode<Entry<K, V>> node) {
        root = node;
    }

    public AVLTree() {
        this(null);
    }

    /**
     * Rebalance method called by insert and remove.  Traverses the path from
     * zPos to the root. For each node encountered, we recompute its height
     * and perform a trinode restructuring if it's unbalanced.
     * the rebalance is completed with O(log n) running time
     */
    void rebalance(AVLNode<Entry<K, V>> zPos) {
        if (zPos.isInternal())
            zPos.setHeight();
        // Improve if possible...
        while (zPos != null) {  // traverse up the tree towards the root
            zPos = (AVLNode<Entry<K, V>>) zPos.getParent();
            if (zPos == null) //reached the root, stop.
                break;
            zPos.setHeight();
            if (!zPos.isBalanced()) {
                // perform a trinode restructuring at zPos's tallest grandchild
                //If yPos (zPos.tallerChild()) denote the child of zPos with greater height.
                //Finally, let xPos be the child of yPos with greater height
                AVLNode<Entry<K, V>> xPos = zPos.tallerChild().tallerChild();

                zPos = (AVLNode<Entry<K, V>>) restructure(xPos); // tri-node restructure (from parent class)
                ((AVLNode<Entry<K, V>>) zPos.getLeft()).setHeight();  // recompute heights
                ((AVLNode<Entry<K, V>>) zPos.getRight()).setHeight();
                zPos.setHeight();
            }
        }
    }


    @Override
    public V insert(K key, V value) {

        Entry<K,V> e = new EntryClass<>(key, value);
        AVLNode<Entry<K,V>> node = (AVLNode<Entry<K, V>>) findNode(key);
        if(node != null) {
            V old = node.element.getValue();
            node.setElement(e);
            return old;
        }
        else {
            AVLNode<Entry<K, V>> newNode = new AVLNode<>(e);
            if (root == null)
                root = newNode;
            else {
                AVLNode<Entry<K,V>> parent = null; // falta buscar o parent
                newNode.setParent(parent);
            }

            rebalance(newNode);
            return null;
        }
    }

    @Override
    public V remove(K key) {
        V toRemove = null;
        AVLNode<Entry<K, V>> node = (AVLNode<Entry<K, V>>) findNode(key);

        if(node != null) {
            toRemove = node.element.getValue();
            AVLNode<Entry<K, V>> parent = null; // falta encontrar o parent do que foi removido
            if (parent == null) rebalance(parent);
        }

        return toRemove;
    }
}
