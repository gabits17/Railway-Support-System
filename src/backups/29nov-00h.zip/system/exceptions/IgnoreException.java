package system.exceptions;

public class IgnoreException extends Exception {

    public IgnoreException() {
        super();
    }
}
