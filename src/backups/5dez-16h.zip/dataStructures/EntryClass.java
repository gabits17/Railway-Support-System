package dataStructures;


import java.io.Serial;

public class EntryClass<K extends Comparable<K>,V> implements Entry<K,V> {
    /**
     * Serial Version UID of the Class
     */
    @Serial
    private static final long serialVersionUID = 0L;
    protected K key;
    protected V value;
    public EntryClass(K key, V value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public K getKey() {
        return key;
    }

    @Override
    public V getValue() {
        return value;
    }

    @Override
    public int compareTo(Entry<K,V> other) {
        int res = key.compareTo(other.getKey());
        /*
        if(res == 0)
            if(value instanceof Comparable)
               // res = ((Comparable<?>) value).compareTo(other.getValue()); //?

         */
        return res;
    }
}
