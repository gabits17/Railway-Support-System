package system;

import dataStructures.Comparator;
import system.train.Train;

public class TrainComparator implements Comparator<Train> {
    @Override
    public int compare(Train o1, Train o2) {
        return o1.getNumber() - o2.getNumber();
    }
}
