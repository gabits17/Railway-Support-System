package dataStructures;

public interface SearchableDoubleList<E> extends List<E>{
    /**
     * Searchs for the Element E in the List.
     * @param element element para procurar
     * @return E if find alguma coisa null otherwise,
     */
    E findEquals(E element);
}
