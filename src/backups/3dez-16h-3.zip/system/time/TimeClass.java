package system.time;

public class TimeClass implements Time {
    /**
     * Serial Version UID of the Class
     */
    static final long serialVersionUID = 0L;

    private final int hour, min;

    public TimeClass(String hour, String min) {
        this.hour = Integer.parseInt(hour);
        this.min = Integer.parseInt(min);
    }

    @Override
    public int getHour() {
        return hour;
    }

    @Override
    public int getMin() {
        return min;
    }

    @Override
    public int compareTo(Time o) {
        int res = hour - o.getHour();
        if(res == 0) res = min - o.getMin();
        return res;
    }
}
