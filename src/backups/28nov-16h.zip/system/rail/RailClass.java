package system.rail;

import dataStructures.*;
import system.TimeStationPair;
import system.station.Station;
import system.station.StationClass;
import system.time.Time;
import system.time.TimeClass;
import system.time.Schedule;
import system.time.ScheduleClass;

public class RailClass implements RailGet, Rail {
    /**
     * Serial Version UID of the Class
     */
    static final long serialVersionUID = 0L;

    /**
     * Name of the rail.
     */
    private final String name;

    /**
     * Set of stations that belong to the rail.
     */
    private final SearchableDoubleList<Station> stations;

    /**
     * Set of schedules that belong to the rail.
     */
    private final Dictionary<TimeStationPair, Schedule> timetables;

    /**
     * Terminal stations.
     */
    private Station term1, term2;

    /**
     * Constructor of an entity Rail.
     * @param name Name of the rail.
     */
    public RailClass(String name) {
        this.name = name;
        stations = new SearchableDoubleListClass<>();
        timetables = new OrderedDoubleList<>(); // 11 testes corretos
        term1 = term2 = null;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int numberOfStations() {
        return stations.size();
    }

    @Override
    public void insertStation(Station station){
        stations.addLast(station);
    }

    @Override
    public TwoWayIterator<Station> listStations() {
        return stations.twoWayIterator();
    }

    @Override
    public void setTerminals() {
        term1 = stations.get(0);
        term2 = stations.get(numberOfStations()-1);
    }

    @Override
    public Station getTerminal1() {
        return term1;
    }

    @Override
    public Station getTerminal2() {
        return term2;
    }

    @Override
    public void insertSchedule(List<TimeStationPair> entries, int train) {
        Schedule t = new ScheduleClass(entries,train);
        TimeStationPair terminal1 = entries.get(0);
        timetables.insert(terminal1,t);
    }

    @Override
    public void removeSchedule(String station, String hour, String minute)  {
        TimeStationPair e = findEntry(station,hour,minute);
        timetables.remove(e);
    }

    @Override
    public Iterator<Schedule> consultRailsSchedule(String station) {
        List<Schedule> departTimetables = new DoubleList<>();
        Iterator<Entry<TimeStationPair, Schedule>> it = timetables.iterator();
        while (it.hasNext()) {
            Entry<TimeStationPair, Schedule> e = it.next();
            Station s = e.getKey().getStation();
            if (s.getName().equalsIgnoreCase(station))
                departTimetables.addLast(e.getValue());
        }
        return departTimetables.iterator();
    }

    @Override
    public boolean isTerminal(Station s) {
        return s.equals(term1) || s.equals(term2);
    }

    @Override
    public Schedule getBestSchedule(String dep, String arrv, String hour, String min) {
        Station arrival = getStation(arrv);
        Station departure = getStation(dep);
        Time expect = new TimeClass(hour,min);
        Time best = null;
        Schedule bestSch = null;

        Iterator<Entry<TimeStationPair, Schedule>> timetablesIt = timetables.iterator();
        while(timetablesIt.hasNext()) {
            Schedule sch = timetablesIt.next().getValue();
            Iterator<TimeStationPair> entriesIt = sch.listEntries();

            boolean found = findDeparture(entriesIt,departure);

            if (found) {
                while (entriesIt.hasNext()) {
                    TimeStationPair ent = entriesIt.next();
                    Time time = ent.getTime();
                    Station st = ent.getStation();

                    if (st.equals(arrival)) {
                        if ((time.compareTo(expect) <= 0) && (best == null || time.compareTo(best) > 0)) {
                                best = time; bestSch = sch;
                        }
                    }
                }
            }
        }
        return bestSch;
    }


    @Override
    public TimeStationPair findEntry(String station, String hour, String min) {
        int h = Integer.parseInt(hour);
        int m = Integer.parseInt(min);
        Iterator<Entry<TimeStationPair, Schedule>> it = timetables.iterator();
        while(it.hasNext()) {
            TimeStationPair entry = it.next().getKey();
            Time t = entry.getTime();
            if(entry.getStation().getName().equalsIgnoreCase(station) &&
                    h == t.getHour() && m == t.getMin())
                return entry;
        }
        return null;
    }

    @Override
    public Station getStation(String name) {
        Station s = new StationClass(name);
        return stations.findEquals(s);
    }

    @Override
    public Iterator<Schedule> listSchedules(TimeStationPair timeStationPair) {
        List<Schedule> tmp = new DoubleList<>();
        Iterator<Entry<TimeStationPair,Schedule>> it = timetables.iterator();
        while(it.hasNext()) {
            Entry <TimeStationPair, Schedule> t = it.next();
            if (timeStationPair.getStation().equals(t.getKey().getStation()) )
                tmp.addLast(t.getValue());
        }
        return tmp.iterator();
    }

    /***** PRIVATE METHODS *****

    /**
     * Finds the departure station of the route that was given.
     * Auxiliary method to implement the MH command.
     * @param entriesIt Iterator of entries of the schedule.
     * @param departure Departure station of the route.
     * @return True if found, false otherwise.
     */
    private boolean findDeparture(Iterator<TimeStationPair> entriesIt, Station departure) {
        boolean foundDeparture = false;
        while (!foundDeparture && entriesIt.hasNext()) {
            TimeStationPair ent = entriesIt.next();
            if (ent.getStation().equals(departure))
                foundDeparture = true;
        }
        return foundDeparture;
    }
}