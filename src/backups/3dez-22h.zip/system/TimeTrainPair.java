package system;

import system.time.Time;
import system.train.Train;

import java.io.Serializable;

public interface TimeTrainPair extends Serializable, Comparable<TimeTrainPair> {
    /**
     * @return Time associated.
     */
    Time getTime();

    /**
     * @return Train associated.
     */
    Train getTrain();
}
