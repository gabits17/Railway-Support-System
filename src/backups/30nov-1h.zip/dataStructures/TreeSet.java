package dataStructures;
import java.io.Serializable;

public interface TreeSet<E extends Comparable<E>> extends Serializable {

    boolean isEmpty();

    int size();

    E insert(E e);

    E remove(E e);

    Iterator<E> iterator();
}
