//package system;
//
//import system.time.Time;
//
//public class TrainInformation implements Comparable<TrainInformation> {
//    private final Time time;
//    private final Train train;
//
//    public TrainInformation(Time time, ){
//
//    }
//
//    public Time getTime(){}
//
//    public Train train(){}
//
//    @Override
//    public int compare(TrainInformation o1) {
//        int res = this.getTime().getHour() - o1.getTime().getHour();
//        if (res == 0) res = this.getTime().getMin() - o1.getTime().getMin();
//        if (res == 0) res = this.getTrain().getNumber() - o1.getTrain().getNumber();
//        return res;
//    }
//}
