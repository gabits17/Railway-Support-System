package system.station;

import dataStructures.*;
import system.TimeTrainComparator;
import system.TimeTrainPair;
import system.TimeTrainPairClass;
import system.rail.Rail;
import system.time.Time;
import system.train.Train;

public  class StationClass implements StationGet, Station {
    /**
     * Serial Version UID of the Class
     */
    static final long serialVersionUID = 0L;
    /**
     * Name of the Station
     */
    private final String name;
    /**
     * Set of rails that the station belongs to
     */
    private final Dictionary<String,Rail> rails;

    /**
     * Set of trains that pass through this station
     */
    private final TreeSet<TimeTrainPair> trains;

    public StationClass(String name) {
        this.name = name;
        this.rails = new SepChainHashTable<>();
        this.trains = new TreeSetClass<>(new TimeTrainComparator());
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void insertTrain(Time time, Train train) {
        trains.insert(new TimeTrainPairClass(time,train));
    }

    @Override
    public void insertRail(Rail r) {
        rails.insert(r.getName(), r);
    }

    @Override
    public void removeRail(Rail r) {
        rails.remove(r.getName());
    }

    @Override
    public int numberOfRails() {
        return rails.size();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        StationClass that = (StationClass) o;
        return name.equals(that.name);
    }

    @Override
    public Iterator<Rail> listRails() {
        Dictionary <String,Rail> railList = new OrderedDoubleList <>();
        Iterator <Entry<String,Rail>> it = rails.iterator();
        while (it.hasNext()) {
            Entry<String,Rail> entry = it.next();
            railList.insert(entry.getKey(), entry.getValue());
        }
        return new VIterator<>(railList.iterator());
    }

    @Override
    public Iterator<TimeTrainPair> listTrains() {
        return trains.iterator();
    }
}
