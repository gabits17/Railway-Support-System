package dataStructures;

public interface SearchableDoubleList<E> extends List<E>{
    /**
     * Searches for the Element E in the List.
     * @param element element para procurar
     * @return E if found, null otherwise.
     */
    E findEquals(E element);
}
