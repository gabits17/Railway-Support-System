package system.exceptions;

/**
 * 2nd phase of the project.
 */

public class NotRailStationException extends Exception {
    /**
     * Serial Version UID of the Class
     */
    static final long serialVersionUID = 0L;
    public NotRailStationException() {
        super();
    }
}
