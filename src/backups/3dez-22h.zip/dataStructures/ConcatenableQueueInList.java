package dataStructures;

public class ConcatenableQueueInList<E> extends QueueInList<E> implements ConcatenableQueue<E> {

    public ConcatenableQueueInList() {
        super();
    }


    public void append(ConcatenableQueue<E> queue) {

        // case: queue is a concatenableQueueInList
        if(queue instanceof ConcatenableQueueInList<?>) {
            DoubleList<E> q1 = (DoubleList<E>) this.list;
            DoubleList<E> q2 = (DoubleList<E>) ((ConcatenableQueueInList<Object>) queue).list;
            q1.append(q2);
        }

        else {
            while(!queue.isEmpty())
                this.enqueue(queue.dequeue());
        }
    }
}
