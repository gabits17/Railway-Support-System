package system;

import system.time.Time;
import system.train.Train;

public class TimeTrainPairClass implements TimeTrainPair {

    private Time time;
    private Train train;

    public TimeTrainPairClass(Time time, Train train) {
        this.time = time;
        this.train = train;
    }

    @Override
    public int compareTo(TimeTrainPair o) {
        int res = time.getHour() - o.getTime().getHour();
        if(res == 0) res = time.getMin() - o.getTime().getMin();
        if(res == 0) res = train.getNumber() - o.getTrain().getNumber();
        return res;
    }

    @Override
    public Time getTime() {
        return time;
    }

    @Override
    public Train getTrain() {
        return train;
    }
}
