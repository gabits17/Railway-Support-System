package dataStructures;

/**
 * AVL tree implementation
 *
 * @author AED team
 * @version 1.0
 *
 * @param <K> Generic type Key, must extend comparable
 * @param <V> Generic type Value
 */
public class AVLTree<K extends Comparable<K>, V>
        extends AdvancedBSTree<K,V> implements OrderedDictionary<K,V> {

    AVLTree(AVLNode<Entry<K, V>> node) {
        root = node;
    }

    public AVLTree() {
        this(null);
    }

    /**
     * Rebalance method called by insert and remove.  Traverses the path from
     * zPos to the root. For each node encountered, we recompute its height
     * and perform a trinode restructuring if it's unbalanced.
     * the rebalance is completed with O(log n) running time
     */
    void rebalance(AVLNode<Entry<K, V>> zPos) {
        if (zPos.isInternal())
            zPos.setHeight();
        // Improve if possible...
        while (zPos != null) {  // traverse up the tree towards the root
            zPos = (AVLNode<Entry<K, V>>) zPos.getParent();
            if (zPos == null) //reached the root, stop.
                break;
            zPos.setHeight();
            if (!zPos.isBalanced()) {
                // perform a trinode restructuring at zPos's tallest grandchild
                //If yPos (zPos.tallerChild()) denote the child of zPos with greater height.
                //Finally, let xPos be the child of yPos with greater height
                AVLNode<Entry<K, V>> xPos = zPos.tallerChild().tallerChild();

                zPos = (AVLNode<Entry<K, V>>) restructure(xPos); // tri-node restructure (from parent class)
                ((AVLNode<Entry<K, V>>) zPos.getLeft()).setHeight();  // recompute heights
                ((AVLNode<Entry<K, V>>) zPos.getRight()).setHeight();
                zPos.setHeight();
            }
        }
    }


    @Override
    public V insert(K key, V value) {
        // Create a new entry with the provided key and value
        Entry<K, V> e = new EntryClass<>(key, value);

        // If the tree is empty, set the root to the new node
        if (root == null) {
            root = new AVLNode<>(e);
            return null; // Return null because this is a new key insertion
        }

        // Otherwise, find the parent node and insert the new node as a left or right child
        AVLNode<Entry<K, V>> currentNode = (AVLNode<Entry<K, V>>) root;
        AVLNode<Entry<K, V>> parentNode = null;

        // Traverse the tree to find the correct position for insertion
        while (currentNode != null) {
            parentNode = currentNode;
            if (key.compareTo(currentNode.element.getKey()) < 0) {
                currentNode = (AVLNode<Entry<K, V>>) currentNode.getLeft();
            } else if (key.compareTo(currentNode.element.getKey()) > 0) {
                currentNode = (AVLNode<Entry<K, V>>) currentNode.getRight();
            } else {
                // Key already exists; update the value
                V oldValue = currentNode.element.getValue();
                currentNode.setElement(e);
                return oldValue; // Return the old value
            }
        }

        // Create a new node for the entry
        AVLNode<Entry<K, V>> newNode = new AVLNode<>(e);

        // Insert the new node as a left or right child of the parent node
        if (key.compareTo(parentNode.element.getKey()) < 0) {
            parentNode.setLeft(newNode);
        } else {
            parentNode.setRight(newNode);
        }

        newNode.setParent(parentNode);
        rebalance(newNode);

        return null; // Return null because this is a new key insertion
    }



    @Override
    public V remove(K key) {
        AVLNode<Entry<K, V>> node = (AVLNode<Entry<K, V>>) findNode(key);

        if (node == null)
            return null;

        V toRemove = node.getElement().getValue();

        AVLNode<Entry<K, V>> nodeParent = (AVLNode<Entry<K, V>>) node.getParent();
        boolean isRoot = node == root;

        if (node.getLeft() == null && node.getRight() == null) {
            if (isRoot)
                root = null;
            else if (nodeParent.getRight() == node)
                nodeParent.setRight(null);
            else
                nodeParent.setLeft(null);

        } else if (node.getLeft() != null && node.getRight() == null || node.getRight() != null && node.getLeft() == null) {
            AVLNode<Entry<K, V>> cur;
            if (node.getLeft() != null )
                cur = (AVLNode<Entry<K,V>>) node.getLeft();
            else
                cur =(AVLNode<Entry<K,V>>) node.getRight();
            if (isRoot) {
                root = cur;
                root.setParent(null);
            } else if (nodeParent.getLeft() == node)
                nodeParent.setLeft(cur);
            else
                nodeParent.setRight(cur);

            cur.setParent(nodeParent);
        } else {
            AVLNode<Entry<K, V>> cur = (AVLNode<Entry<K, V>>) node.getRight();
            while (cur.getLeft() != null)
                cur = (AVLNode<Entry<K, V>>) cur.getLeft();
            node.setElement(cur.getElement());

            AVLNode<Entry<K, V>> curParent = (AVLNode<Entry<K, V>>) cur.getParent();
            if (curParent.getLeft() == cur)
                curParent.setLeft(cur.getRight());
            else
                curParent.setRight(cur.getRight());
            if (cur.getRight() != null)
                cur.getRight().setParent(curParent);
        }

        currentSize--;
        return toRemove;
    }

}
