package dataStructures;

public class AVLTreeSet<E extends Comparable<E>> extends AdvancedTreeSet<E> {

    public AVLTreeSet(Comparator<E> comparator) {
        super(comparator);
    }

    @Override
    public E insert(E e) {
        Stack<PathStep<E>> path = new StackInList<>();
        BSTNode<E> node = this.findNode(e, path);
        if (node == null) {
            AVLSetNode<E> newLeaf = new AVLSetNode<>(e);
            this.linkSubtree(newLeaf, path.top());
            currSize++;
            this.reorganizeInsert(path);
            return null;
        } else {
            E old = node.getElement();
            node.setElement(e);
            return old;
        }
    }

    protected void reorganizeInsert(Stack<PathStep<E>> path) {
        boolean grew = true;
        PathStep<E> lastStep = path.pop();
        AVLSetNode<E> parent = (AVLSetNode<E>) lastStep.parent;
        while (grew && parent != null) {
            if (lastStep.isLeftChild) { // The parent's left subtree has grown.
                switch (parent.getBalance()) {
                    case 'L' -> {
                        this.rebalanceInsLeft(parent, path);
                        grew = false;
                    }
                    case 'E' -> parent.setBalance('L');
                    case 'R' -> {
                        parent.setBalance('E');
                        grew = false;
                    }
                }
            } else { // The parent's right subtree has grown.
                switch (parent.getBalance()) {
                    case 'L' -> {
                        parent.setBalance('E');
                        grew = false;
                    }
                    case 'E' -> parent.setBalance('R');

                    case 'R' -> {
                        this.rebalanceInsRight(parent, path);
                        grew = false;
                    }
                }
            }
            lastStep = path.pop();
            parent = (AVLSetNode<E>) lastStep.parent;
        }
    }

    protected void rebalanceInsLeft(AVLSetNode<E> parent, Stack<PathStep<E>> path) {
        AVLSetNode<E> left = (AVLSetNode<E>) parent.getLeft();
        switch (left.getBalance()) {
            case 'L' -> this.rotateLeft1L(parent, left, path);
            case 'R' -> this.rotateLeft2(parent, left, path);
        }
    }

    protected void rebalanceInsRight(AVLSetNode<E> parent, Stack<PathStep<E>> path) {
        AVLSetNode<E> right = (AVLSetNode<E>) parent.getRight();
        switch (right.getBalance()) {
            case 'L' -> this.rotateRight2(parent, right, path);
            case 'R' -> this.rotateRight1R(parent, right, path);
        }
    }

    @Override
    public E remove(E e) {
        Stack<PathStep<E>> path = new StackInList<>();
        BSTNode<E> node = this.findNode(e, path);
        if (node == null) return null;
        else {
            E old = node.getElement();
            if (node.getLeft() == null) // The left subtree is empty.
                this.linkSubtree(node.getRight(), path.top());
            else if (node.getRight() == null) // The right subtree is empty
                this.linkSubtree(node.getLeft(), path.top());
            else { // Node has 2 children. Replace the node's element with the minNode of the right subtree.
                path.push(new PathStep<>(node, false));
                BSTNode<E> min = this.minNode(node.getRight(), path);
                node.setElement(min.getElement());
                this.linkSubtree(min.getRight(), path.top());
            }
            currSize--;
            this.reorganizeRemove(path);
            return old;
        }
    }

    protected void reorganizeRemove(Stack<PathStep<E>> path) {
        PathStep<E> lastStep = path.pop(); // Node that has been removed.
        AVLSetNode<E> parent = (AVLSetNode<E>) lastStep.parent; // Parent of the node that has been removed.
        boolean decrease = true;
        while (decrease && parent != null) {
            if (lastStep.isLeftChild) { // Parent's left subtree has decreased.
                switch (parent.getBalance()) {
                    case 'L' -> parent.setBalance('E');
                    case 'E' -> {
                        parent.setBalance('R');
                        decrease = false;
                    }
                    case 'R' -> decrease = this.rebalanceRemoveRight(parent, path);
                }
            } else { // Parent's right subtree has decreased.
                switch (parent.getBalance()) {
                    case 'L' -> decrease = this.rebalanceRemoveLeft(parent, path);
                    case 'E' -> {
                        parent.setBalance('L');
                        decrease = false;
                    }
                    case 'R' -> parent.setBalance('E');
                }
            }
            lastStep = path.pop();
            parent = (AVLSetNode<E>) lastStep.parent;
        }
    }

    protected boolean rebalanceRemoveRight(AVLSetNode<E> parent, Stack<PathStep<E>> path) {
        AVLSetNode<E> right = (AVLSetNode<E>) parent.getRight();
        boolean decrease = true;
        switch (right.getBalance()) {
            case 'L' -> this.rotateRight2(parent,right,path);
            case 'E' -> {
                this.rotateRight1E(parent,right,path);
                decrease = false;
            }
            case 'R' -> this.rotateRight1R(parent,right,path);
        }
        return decrease;
    }

    protected boolean rebalanceRemoveLeft(AVLSetNode<E> parent, Stack<PathStep<E>> path) {
        AVLSetNode<E> left = (AVLSetNode<E>) parent.getLeft();
        boolean decrease = true;
        switch (left.getBalance()) {
            case 'L' -> this.rotateLeft1L(parent,left,path);
            case 'E' -> {
                this.rotateLeft1E(parent,left,path);
                decrease = false;
            }
            case 'R' -> this.rotateLeft2(parent,left,path);
        }
        return decrease;
    }

    protected void rotateLeft1L(AVLSetNode<E> theRoot, AVLSetNode<E> leftChild, Stack<PathStep<E>> path) {
        theRoot.setBalance('E');
        leftChild.setBalance('E');
        this.singleLeftRotation(theRoot,leftChild,path);
    }

    protected void rotateLeft1E(AVLSetNode<E> theRoot, AVLSetNode<E> leftChild, Stack<PathStep<E>> path) {
        leftChild.setBalance('R');
        this.singleLeftRotation(theRoot,leftChild,path);
    }

    protected void rotateRight1R(AVLSetNode<E> theRoot, AVLSetNode<E> rightChild, Stack<PathStep<E>> path) {
        theRoot.setBalance('E');
        rightChild.setBalance('E');
        this.singleRightRotation(theRoot,rightChild,path);
    }

    protected void rotateRight1E(AVLSetNode<E> theRoot, AVLSetNode<E> rightChild, Stack<PathStep<E>> path) {
        rightChild.setBalance('L');
        this.singleRightRotation(theRoot,rightChild,path);
    }

    protected void rotateLeft2(AVLSetNode<E> theRoot, AVLSetNode<E> leftChild, Stack<PathStep<E>> path) {
        AVLSetNode<E> rightGrandchild = (AVLSetNode<E>) leftChild.getRight();
        switch ( rightGrandchild.getBalance() ) {
            case 'L':
                leftChild.setBalance('E');
                theRoot.setBalance('R');
                break;
            case 'E':
                leftChild.setBalance('E');
                theRoot.setBalance('E');
                break;
            case 'R':
                leftChild.setBalance('L');
                theRoot.setBalance('E');
                break;
        }
        rightGrandchild.setBalance('E');
        this.rotateLeft(theRoot, leftChild, rightGrandchild, path);
    }

    protected void rotateRight2(  AVLSetNode<E> theRoot, AVLSetNode<E> rightChild, Stack<PathStep<E>> path ) {
        AVLSetNode<E> leftGrandchild = (AVLSetNode<E>) rightChild.getLeft();
        switch ( leftGrandchild.getBalance() ) {
            case 'L':
                theRoot.setBalance('E');
                rightChild.setBalance('R');
                break;
            case 'E':
                theRoot.setBalance('E');
                rightChild.setBalance('E');
                break;
            case 'R':
                theRoot.setBalance('L');
                rightChild.setBalance('E');
                break;
        }
        leftGrandchild.setBalance('E');
        this.rotateRight(theRoot, rightChild, leftGrandchild, path);
    }
}
