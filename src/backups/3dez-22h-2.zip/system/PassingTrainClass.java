package system;

import system.time.Time;
import system.train.Train;

public record PassingTrainClass(Time time, Train train) implements PassingTrain {


    public PassingTrainClass {
    }

    public int compareTo(PassingTrain o) {
        int res = time.getHour() - o.time().getHour();
        if(res == 0) res = time.getMin() - o.time().getMin();
        if(res == 0) res = train.getNumber() - o.train().getNumber();
        return res;
    }
}
