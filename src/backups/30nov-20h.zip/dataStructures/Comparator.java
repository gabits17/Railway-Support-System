package dataStructures;

import java.io.Serializable;

public interface Comparator<E> extends Serializable {

    int compare(E o1, E o2);
}
