package system.rail;

import dataStructures.*;
import system.time.TimeStationPair;
import system.station.Station;
import system.station.StationClass;
import system.time.Time;
import system.time.TimeClass;
import system.train.Train;
import system.train.TrainClass;

public class RailClass implements RailGet, Rail {
    /**
     * Serial Version UID of the Class
     */
    static final long serialVersionUID = 0L;

    /**
     * Name of the rail.
     */
    private final String name;

    /**
     * Set of stations that belong to the rail.
     */
    private final SearchableDoubleList<Station> stations;
    /**
     * Set of trains that contains a schedule through this rail.
     * Ordered by time of departure.
     */
//    private final Dictionary<TimeStationPair, Train> trains;
    // CRIAR DOIS CONJUNTOS E SEPARAR OS COMBOIOS POR SENTIDO
    // JÁ ORDENADOS POR HORA DE PARTIDA
//    private OrderedDictionary<Time, Train> direction1;
//    private OrderedDictionary<Time, Train> direction2;
    private Dictionary<Time,Train> trainsDir1;
    private Dictionary<Time,Train> trainsDir2;
    /**
     * Terminal stations.
     */
    private Station term1, term2;

    /**
     * Constructor of an entity Rail.
     * @param name Name of the rail.
     */
    public RailClass(String name) {
        this.name = name;
        this.stations = new SearchableDoubleListClass<>();
        this.trainsDir1 = new OrderedDoubleList<>();
        this.trainsDir2 = new OrderedDoubleList<>();
        this.term1 = this.term2 = null;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int numberOfStations() {
        return stations.size();
    }

    @Override
    public void insertStation(Station station) {
        stations.addLast(station);
    }

    @Override
    public TwoWayIterator<Station> listStations() {
        return stations.twoWayIterator();
    }

    @Override
    public void setTerminals() {
        term1 = stations.get(0);
        term2 = stations.get(numberOfStations() - 1);
    }

    @Override
    public Station getTerminal1() {
        return term1;
    }

    @Override
    public Station getTerminal2() {
        return term2;
    }
    
    @Override
    public void insertTrain(List<TimeStationPair> entries, int train) {
        Train t = new TrainClass(entries,train);
        TimeStationPair dep = entries.get(0);
        Time depTime = dep.getTime();
        if(dep.getStation().getName().equalsIgnoreCase(term1.getName())) trainsDir1.insert(depTime, t);
        else trainsDir2.insert(depTime, t);
        insertTrainInStations(entries,t);
    }

    private void insertTrainInStations(List<TimeStationPair> entries, Train train) {
        Iterator<TimeStationPair> it = entries.iterator();
        while(it.hasNext()) {
            TimeStationPair entry = it.next();
            Station s = entry.getStation();
            s.insertTrain(entry.getTime(),train);
        }
    }

    @Override
    public void removeTrain(String station, String hour, String minute) {
        Time aux = new TimeClass(hour,minute);
        Train t;
        if(station.equalsIgnoreCase(term1.getName())) {
            t = trainsDir1.find(aux);
            trainsDir1.remove(aux);
        }
        else {
            t = trainsDir2.find(aux);
            trainsDir2.remove(aux);
        }
        removeTrainFromStations(aux,t);
    }

    private void removeTrainFromStations(Time t, Train tr) {
        Iterator<Station> it = stations.iterator();
        while (it.hasNext()) {
            Station s = it.next();
            s.removeTrain(t, tr.getNumber());
        }
    }

    @Override
    public Iterator<Train> listTrainsDepartingAt(Station dep) {
        Iterator<Entry<Time,Train>> it;
        if(dep.getName().equalsIgnoreCase(term1.getName())) it = trainsDir1.iterator();
        else it = trainsDir2.iterator();

        return new VIterator<>(it);
    }

    @Override
    public boolean isTerminal(Station s) {
        return s.equals(term1) || s.equals(term2);
    }

    @Override
    public Train getBestSchedule(String dep, String arrv, String hour, String min) {
        Station departure = getStation(dep);
        Station arrival = getStation(arrv);
        boolean direction = findDirection(departure,arrival);
        Iterator<Entry<Time,Train>> it;
        if(direction) it = trainsDir1.iterator();
        else it = trainsDir2.iterator();
        Time expect = new TimeClass(hour,min);
        Time best = null;
        Train bestSch = null;

        while(it.hasNext()) {
            Train t = it.next().getValue();
            Iterator<TimeStationPair> schIt = t.listScheduleEntries();
            boolean found = findDeparture(schIt,departure);
            if(found) {
                while(schIt.hasNext()) {
                    TimeStationPair p = schIt.next();
                    Time time = p.getTime();
                    Station st = p.getStation();
                    if (st.equals(arrival)) {
                        if ((time.compareTo(expect) <= 0) && (best == null || time.compareTo(best) > 0)) {
                                best = time; bestSch = t;
                       }
                    }
                }
            }
        }
        return bestSch;
    }

    // Retorna true se o sentido for o normal; false caso contrário.
    private boolean findDirection(Station departure, Station arrival) {
        int dep_idx = stations.find(departure);
        int arr_idx = stations.find(arrival);
        return dep_idx < arr_idx;
    }

    @Override
    public Train findSchedule(String dep, String hour, String min) {
        int h = Integer.parseInt(hour);
        int m = Integer.parseInt(min);
        Station departure = getStation(dep);
        Iterator<Entry<Time,Train>> it;
        if(departure.equals(term1)) it = trainsDir1.iterator();
        else it = trainsDir2.iterator();
        while(it.hasNext()) {
            Entry<Time,Train> e = it.next();
            Time time = e.getKey();
            Train t = e.getValue();
            if(t.getDepartureStation().equals(departure) && h == time.getHour() && m == time.getMin())
                return t;
        }
        return null;
    }

    @Override
    public Station getStation(String name) {
        Station s = new StationClass(name);
        return stations.findEquals(s);
    }

    @Override
    public void removeTrainsFromStations() {
        Iterator<Entry<Time,Train>> it1 = trainsDir1.iterator();
        while (it1.hasNext()) {
            Entry<Time,Train> e = it1.next();
            Train train = e.getValue();
            Iterator<TimeStationPair> schIt = train.listScheduleEntries();
            while (schIt.hasNext()) {
                TimeStationPair p = schIt.next();
                Station s = p.getStation();
                Time t = p.getTime();
                s.removeTrain(t,train.getNumber());
            }
        }
    }

    /***** PRIVATE METHODS *****

    /**
     * Finds the departure station of the route that was given.
     * Auxiliary method to implement the MH command.
     * @param entriesIt Iterator of entries of the schedule.
     * @param departure Departure station of the route.
     * @return True if found, false otherwise.
     */
    private boolean findDeparture(Iterator<TimeStationPair> entriesIt, Station departure) {
        boolean foundDeparture = false;
        while (!foundDeparture && entriesIt.hasNext()) {
            TimeStationPair ent = entriesIt.next();
            if (ent.getStation().equals(departure))
                foundDeparture = true;
        }
        return foundDeparture;
    }
}