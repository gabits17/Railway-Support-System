package dataStructures;

public class InvertibleQueueInList<E> extends QueueInList<E> implements InvertibleQueue<E> {

    private boolean inverted;
    public InvertibleQueueInList() {
        super();
        this.inverted = false;
    }

    @Override
    public void invert() {
        this.inverted = !inverted;
    }

    @Override
    public void enqueue(E elem) {
        if(!inverted)
            list.addLast(elem); // super.enqueue(elem);
        else
            list.addFirst(elem);
    }

    @Override
    public E dequeue() throws EmptyQueueException {
        if(this.isEmpty())
            throw new EmptyQueueException();
        if(!inverted)
            return list.removeFirst(); // super.dequeue();
        else
            return list.removeLast();
    }
}
