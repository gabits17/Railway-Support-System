package dataStructures;
import dataStructures.exceptions.NoSuchElementException;

class BSTKeyOrderIterator<K,V> implements Iterator<Entry<K,V>> {


	protected BSTNode<Entry<K,V>> root;

	protected Stack<BSTNode<Entry<K,V>>> stackNodes;


	BSTKeyOrderIterator(BSTNode<Entry<K,V>> root){
		this.root = root;
		stackNodes = new StackInList<>();
		pushPathToMinimum(root);
	}

	/**
	 * Put tree nodes in the stack by order.
	 * @param node node.
	 */
	protected void pushPathToMinimum(BSTNode<Entry<K,V>> node) {
		if (node != null){
			stackNodes.push(node);
			this.pushPathToMinimum(node.getLeft());
		}
	}

	//O(1) para todos os casos
	public boolean hasNext(){
		return !stackNodes.isEmpty();
	}


	public Entry<K,V> next( ) throws NoSuchElementException {
		if (!hasNext()) throw new NoSuchElementException();
		else {
			BSTNode<Entry<K,V>> next = stackNodes.pop();
			pushPathToMinimum(next.getRight());
			return next.getElement();
		}
	}

	public void rewind( ){
		stackNodes = new StackInList<>();
		pushPathToMinimum(root);
	}
}