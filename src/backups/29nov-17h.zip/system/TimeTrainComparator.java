package system;

import dataStructures.Comparator;
import dataStructures.Entry;
import system.time.Time;
import system.train.Train;

public class TimeTrainComparator implements Comparator<Entry<Time, Train>> {
    @Override
    public int compare(Entry<Time, Train> o1, Entry<Time, Train> o2) {
        int res = o1.getKey().getHour() - o2.getKey().getHour();
        if (res == 0) res = o1.getKey().getMin() - o2.getKey().getMin();
        if (res == 0) res = o1.getValue().getNumber() - o2.getValue().getNumber();
        return res;
    }

}
