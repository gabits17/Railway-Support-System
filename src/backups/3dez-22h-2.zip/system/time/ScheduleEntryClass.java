package system.time;

import system.station.Station;

/**
 * @param station Station corresponding to this entry of a schedule.
 * @param time    Time corresponding to this entry of a schedule.
 */
public record ScheduleEntryClass(Station station, Time time) implements ScheduleEntry {

    /**
     * Constructor of a pair Time-Station, aka schedule entry.
     * @param station Station associated.
     * @param time    Time associated.
     */
    public ScheduleEntryClass {
    }

    public int compareTo(ScheduleEntry o) {
        int res = time.compareTo(o.time());
        if (res == 0) res = station.getName().compareTo(o.station().getName());
        return res;
    }
}
