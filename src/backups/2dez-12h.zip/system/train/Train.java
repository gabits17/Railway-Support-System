package system.train;

import dataStructures.Iterator;
import system.time.TimeStationPair;

import java.io.Serializable;
/**
 * Represents the entity Train.
 * Has a unique number as an ID and a list of entries that form a schedule - pair Time Station.
 * @author Gabriela Silva (67286) gt.silva@campus.fct.unlt.pt
 * @author Clara DIas (67215) cso.dias@campus.fct.unl.pt
 */
public interface Train extends Serializable, Comparable<Train> {
    /**
     * @return Number of the train that works through this schedule.
     */
    int getNumber();

    /**
     * Lists every entry of the schedule.
     * @return Iterator of the entries of the schedule.
     */
    Iterator<TimeStationPair> listScheduleEntries();
}
