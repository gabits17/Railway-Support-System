package system;
import dataStructures.*;
import system.exceptions.*;
import system.rail.*;
import system.station.*;
import system.time.Time;
import system.time.TimeClass;
import system.time.TimeStationPair;
import system.time.TimeStationPairClass;
import system.train.Train;

public class RailWayNetworkClass implements RailWayNetwork {
    /**
     * Serial Version UID of the Class
     */
    static final long serialVersionUID = 0L;

    /**
     * Sets of rails in the system.
     */
    private final Dictionary<String,Rail> rails;

    /**
     * Sets of stations in the system.
     */
    private final Dictionary<String, Station> stations;

    /**
     * Constructor of the system.
     */
    public RailWayNetworkClass() {
        rails = new SepChainHashTable<>();
        stations = new SepChainHashTable<>();
    }


    @Override
    public void insertRail(String railName, List<String> stationsNames) throws ExistentRailException {
        Rail r = getRail(railName);
        if(r != null)
            throw new ExistentRailException();

        Rail rail = new RailClass(railName);
        rails.insert(railName.toLowerCase(),rail);
        addStationsToRail(rail,stationsNames);
    }


    @Override
    public void removeRail(String railName) throws NonExistentRailException {
        Rail r = getRail(railName);
        if(r == null)
            throw new NonExistentRailException();

        removeRailFromStations(r);
        rails.remove(railName.toLowerCase());
    }

    @Override
    public Iterator<Station> listRailStations(String railName) throws NonExistentRailException {
        Rail r = getRail(railName);
        if(r == null)
            throw new NonExistentRailException();
        return r.listStations();
    }

    @Override
    public void saveEntry(String station, String hour, String min, List<TimeStationPair> entries) {
        Station s = getStation(station);
        Time t = new TimeClass(hour,min);
        entries.addLast(new TimeStationPairClass(s,t));
    }

    @Override
    public void insertSchedule(String rail, List<TimeStationPair> scheduleEntries, int train)
            throws NonExistentRailException, InvalidScheduleException {
        Rail r = getRail(rail);
        if(r == null)
            throw new NonExistentRailException();

        validateSchedule(r,scheduleEntries);
        r.insertTrain(scheduleEntries,train);
        Iterator <TimeStationPair> it = scheduleEntries.iterator();
        while(it.hasNext()){
            TimeStationPair pair = it.next();
            Station s = pair.getStation();
            s.insertTrain(train, pair.getTime());
        }
    }

    @Override
    public void removeSchedule(String rail, String station, String hour, String minute)
            throws NonExistentRailException, NonExistentScheduleException {
        Rail r = getRail(rail);
        if(r == null)
            throw new NonExistentRailException();
        if(r.findEntry(station,hour,minute) == null)
            throw new NonExistentScheduleException();
        r.removeTrain(station,hour,minute);
    }

    @Override
    public Iterator<Train> consultRailSchedule(String rail, String station)
            throws NonExistentRailException, NonExistentDepartureStationException {
        Rail r = getRail(rail);
        if(r == null)
            throw new NonExistentRailException();
        Station s = getStation(station);
        if(!r.isTerminal(s))
            throw new NonExistentDepartureStationException();
        return r.consultRailsSchedule(station);
    }


    @Override
    public Iterator<TimeStationPair> listBestSchedule(String rail, String dep, String arrv, String hour, String min)
            throws NonExistentRailException, NonExistentDepartureStationException, ImpossibleRouteException {
        Rail r = getRail(rail);
        if(r == null)
            throw new NonExistentRailException();
        if(r.getStation(dep) == null)
            throw new NonExistentDepartureStationException();
        if(r.getStation(arrv) == null)
            throw new ImpossibleRouteException();

        Train best = r.getBestSchedule(dep,arrv,hour,min);
        if(best == null) throw new ImpossibleRouteException();

        return best.listScheduleEntries();
    }

    @Override
    public int getBestTrain(String rail, String dep, String arrv, String hour, String min) {
        Rail r = getRail(rail);
        return r.getBestSchedule(dep, arrv, hour, min).getNumber();
    }

    @Override
    public Iterator<Rail> listStationRails(String stationName)
            throws NonExistentStationException {
        Station s = getStation(stationName);
        if (s == null) throw new NonExistentStationException();
        return s.listRails();
    }

    /**** PRIVATE METHODS ****/
    /**
     * @param railName Name of the rail.
     * @return Rail with name <railName> if it exists. Null otherwise.
     */
    private Rail getRail(String railName) {
        return rails.find(railName.toLowerCase());
    }

    /**
     * @param stationName Name of the station.
     * @return Station with name <stationName> if it exists. Null otherwise.
     */
    private Station getStation(String stationName) {
        return stations.find(stationName.toLowerCase());
    }


    /**
     * Adds a list of stations to a rail.
     * If a station is already in the system, it just adds the station to the rail.
     * If not, it creates a new station.
     * @param rail – The rail where the stations are being inserted.
     * @param stationsNames – List of the names of the stations.
     * @pre stationsNames.size() > 1
     * */
    private void addStationsToRail(Rail rail, List<String> stationsNames) {
        for(int i = 0; i < stationsNames.size(); i++) {
            String stationName = stationsNames.get(i);
            Station s = getStation(stationName);

            if(s == null) {
                s = new StationClass(stationName);
                stations.insert(stationName.toLowerCase(),s);
            }
            s.insertRail(rail);
            rail.insertStation(s);
        }
        rail.setTerminals();
    }

    /**
     * Removes a rail from every station that belonged to it.
     * If a station only belongs to this rail, that station is also removed from the system.
     * @param r Rail being removed.
     */
    private void removeRailFromStations(Rail r) {
        TwoWayIterator<Station> it = r.listStations();
        while (it.hasNext()) {
            Station s = it.next();

            if(stationIsOnlyPartOfOneRail(s))
                stations.remove(s.getName().toLowerCase());

            s.removeRail(r);
        }
    }

    /**
     * Checks if the station only belongs to one rail.
     * @param s Station being analyzed.
     * @return True if it is, false otherwise.
     */
    private boolean stationIsOnlyPartOfOneRail(Station s) {
        return s.numberOfRails() == 1;
    }

    /**
     * Checks if every entry in entries is valid to create the schedule.
     * @param r Rail where the schedule is being inserted.
     * @param entries List of entries of the schedule.
     */
    private void validateSchedule(Rail r, List<TimeStationPair> entries)
            throws InvalidScheduleException {
        if(entries.size() < 2) throw new InvalidScheduleException();

        Station departure = entries.get(0).getStation();
        if(!r.isTerminal(departure)) throw new InvalidScheduleException();

        boolean way = departure.equals(r.getTerminal1());

        Iterator<TimeStationPair> scheduleEntriesIterator = entries.iterator();
        TwoWayIterator<Station> railStationsIterator = r.listStations();
        if(!way) railStationsIterator.fullForward();

        Time previous = scheduleEntriesIterator.next().getTime();
        while(scheduleEntriesIterator.hasNext()) {
            TimeStationPair p = scheduleEntriesIterator.next();
            Time current = p.getTime();
            Station scheduleStation = p.getStation();

            if(current.compareTo(previous) <= 0)
                throw new InvalidScheduleException();
            previous = current;

            boolean foundStation = false;
            if(way) {
                while(railStationsIterator.hasNext() && !foundStation)
                    if(railStationsIterator.next().equals(scheduleStation))
                        foundStation = true;
            } else {
                while(railStationsIterator.hasPrevious() && !foundStation)
                    if(railStationsIterator.previous().equals(scheduleStation))
                        foundStation = true;
            }
            if(!foundStation)
                throw new InvalidScheduleException();
        }
    }

    private boolean checkOvertaking(Rail r, List<TimeStationPair> entries) {
        Iterator<Train> it =  r.listSchedules(entries.get(0));
        while(it.hasNext()) {
            Train schedule = it.next();
            Iterator<TimeStationPair> newScheduleIt = entries.iterator();
            Iterator<TimeStationPair> scheduleIt = schedule.listScheduleEntries();
            TimeStationPair train1;
            boolean leaveLater = false;

            while(scheduleIt.hasNext()) {
                TimeStationPair train = scheduleIt.next();
                if(newScheduleIt.hasNext()) {
                    train1 = newScheduleIt.next();
                }
                else break;
                if (train.getStation() == train1.getStation()) {
                    if (train.getTime().compareTo(train1.getTime()) < 0)
                        leaveLater = true;
                    else if (train.getTime().compareTo(train.getTime()) >= 0 && leaveLater)
                        return false;
                    else if(train.getTime().compareTo(train.getTime()) == 0)
                        return false;
                }
            }
        }
        return true;
    }
}
