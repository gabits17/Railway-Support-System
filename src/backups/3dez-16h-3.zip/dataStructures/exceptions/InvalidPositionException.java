package dataStructures.exceptions;

public class InvalidPositionException extends RuntimeException{
    static final long serialVersionUID = 0L;
}

