package system;

import dataStructures.Comparator;

public class TimeTrainComparator implements Comparator<TimeTrainPair> {

    @Override
    public int compare(TimeTrainPair o1, TimeTrainPair o2) {
        int res = o1.getTime().getHour() - o2.getTime().getHour();
        if (res == 0) res = o1.getTime().getMin() - o2.getTime().getMin();
        if (res == 0) res = o1.getTrain().getNumber() - o2.getTrain().getNumber();
        return res;
    }
}
