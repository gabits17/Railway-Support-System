package system;

import dataStructures.Comparator;
import system.data.PassingTrain;

public class PassingTrainComparator implements Comparator<PassingTrain> {
    @Override
    public int compare(PassingTrain o1, PassingTrain o2) {
        int res = o1.time().compareTo(o2.time());
        if(res == 0) res = o1.train().compareTo(o2.train());
        return res;
    }
}
