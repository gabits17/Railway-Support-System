package system.time;

import system.station.Station;
import system.time.Time;

import java.io.Serializable;
/**
 * Entity that represents an entry in a schedule.
 * It is a pair Time - Station that represents the time when a train goes by the station in a schedule.
 * @author Gabriela Silva (67286) gt.silva@campus.fct.unlt.pt
 * @author Clara DIas (67215) cso.dias@campus.fct.unl.pt
 */
public interface TimeStationPair extends Serializable, Comparable<TimeStationPair> {
    /**
     * @return The station associated.
     */
    Station getStation();

    /**
     * @return The time associated.
     */
    Time getTime();
}
