package system.data;

import system.base.Time;
import system.base.Train;

import java.io.Serializable;

public interface PassingTrain extends Serializable, Comparable<PassingTrain> {
    /**
     * @return Time associated.
     */
    Time time();

    /**
     * @return Train associated.
     */
    Train train();
}
