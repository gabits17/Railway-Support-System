/**
 * List of possible feedbacks from the program.
 * @author Gabriela Silva (67286) gt.silva@campus.fct.unlt.pt
 * @author Clara DIas (67215) cso.dias@campus.fct.unl.pt
 */
public enum Output {
    SUCESSO_INSERCAO_LINHA("Inserção de linha com sucesso.\n"),
    LINHA_EXISTENTE("Linha existente.\n"),
    SUCESSO_REMOCAO_LINHA("Remoção de linha com sucesso.\n"),
    LINHA_INEXISTENTE("Linha inexistente.\n"),
    ESTAÇÃO_INEXISTENTE("Estação inexistente.\n"),
    SUCESSO_CRIACAO_HORARIO("Criação de horário com sucesso.\n"),
    HORARIO_INVALIDO("Horário inválido.\n"),
    HORARIO_INEXISTENTE("Horário inexistente.\n"),
    SUCESSO_REMOCAO_HORARIO("Remoção de horário com sucesso.\n"),
    PARTIDA_INEXISTENTE("Estação de partida inexistente.\n"),
    PERCURSO_IMPOSSIVEL("Percurso impossível.\n"),
    APLICACAO_TERMINADA("Aplicação terminada.\n");

    /**
     * String of the feedback.
     */
    private final String out;

    /**
     * Constructor of the output.
     * @param out String of the ouput.
     */
    Output(String out) {
        this.out = out;
    }

    /**
     * Prints the output.
     * @return The output's string.
     */
    public String printOutput() {
        return out;
    }
}
