package dataStructures;

import dataStructures.exceptions.NoSuchElementException;

import java.io.Serial;

public class TreeSetIterator<E extends Comparable<E>> implements Iterator<E> {

    /**
     * Serial Version UID of the Class
     */
    @Serial
    private static final long serialVersionUID = 0L;

    /**
     * Stack that contains all nodes sorted.
     */
    protected Stack<BSTNode<E>> stack;
    /**
     * Root node.
     */
    protected BSTNode<E> root;

    /**
     * TreeSetIterator constructor.
     * @param root Root node.
     * @author Gabriela Silva (67286) gt.silva@campus.fct.unlt.pt
     * @author Clara Dias (67215) cso.dias@campus.fct.unl.pt
     */
    public TreeSetIterator(BSTNode<E> root) {
        this.root = root;
        stack = new StackInList<>();
        sort(root);
    }

    /**
     * Sorts the nodes in stack.
     * @param root Root node.
     */
    private void sort(BSTNode<E> root) {
        if (root != null) {
            stack.push(root);
            this.sort(root.getLeft());
        }
    }

    @Override
    public boolean hasNext() {
        return !stack.isEmpty();
    }

    @Override
    public E next() throws NoSuchElementException {
        if(!hasNext()) throw new NoSuchElementException();
        BSTNode<E> node = stack.pop();
        if(node.getRight() != null) sort(node.getRight());
        return node.getElement();
    }

    @Override
    public void rewind() {
        stack = new StackInList<>();
        sort(root);
    }
}
