package dataStructures;

import java.io.Serial;

public class AdvancedTreeSet<E extends Comparable<E>>extends TreeSetClass<E> {
    /**
     * Serial Version UID of the Class
     */
    @Serial
    private static final long serialVersionUID = 0L;

    protected AdvancedTreeSet(Comparator<E> comparator) {
        super(comparator);
    }

    protected BSTNode<E> findNode(E el, Stack<PathStep<E>> path) {
        path.push(new PathStep<>(null,false));
        BSTNode<E> node = root;
        while(node != null) {
            E e = node.getElement();
            int compRes = comp.compare(el,e);
            if(compRes == 0) return node;
            else if(compRes < 0) {
                path.push(new PathStep<>(node,true));
                node = node.getLeft();
            } else {
                path.push(new PathStep<>(node,false));
                node = node.getRight();
            }
        }
        return null;
    }

    protected BSTNode<E> minNode(BSTNode<E> theRoot, Stack<PathStep<E>> path) {
        BSTNode<E> node = theRoot;
        while(node.getLeft() != null) {
            path.push(new PathStep<>(node,true));
            node = node.getLeft();
        }
        return node;
    }

    protected void singleLeftRotation(BSTNode<E> theRoot, BSTNode<E> leftChild, Stack<PathStep<E>> path) {
        theRoot.setLeft(leftChild.getRight());
        leftChild.setRight(theRoot);
        this.linkSubtree(leftChild, path.top());
    }

    protected void singleRightRotation(BSTNode<E> theRoot, BSTNode<E> rightChild, Stack<PathStep<E>> path) {
        theRoot.setRight(rightChild.getLeft());
        rightChild.setLeft(theRoot);
        this.linkSubtree(rightChild, path.top());
    }

    protected void rotateLeft(BSTNode<E> theRoot, BSTNode<E> leftChild, BSTNode<E> rightGrandchild, Stack<PathStep<E>> path) {
        leftChild.setRight(rightGrandchild.getLeft());
        theRoot.setLeft(rightGrandchild.getRight());
        rightGrandchild.setLeft(leftChild);
        rightGrandchild.setRight(theRoot);
        this.linkSubtree(rightGrandchild, path.top());
    }

    protected void rotateRight(BSTNode<E> theRoot, BSTNode<E> rightChild, BSTNode<E> leftGrandchild, Stack<PathStep<E>> path) {
        theRoot.setRight(leftGrandchild.getLeft());
        rightChild.setLeft(leftGrandchild.getRight());
        leftGrandchild.setLeft(theRoot);
        leftGrandchild.setRight(rightChild);
        this.linkSubtree(leftGrandchild, path.top());
    }
}
