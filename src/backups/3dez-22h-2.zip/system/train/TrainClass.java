package system.train;

import dataStructures.*;
import system.station.Station;
import system.time.ScheduleEntry;

public class TrainClass implements Train {
    /**
     * Serial Version UID of the Class
     */
    static final long serialVersionUID = 0L;

    /**
     * Unique ID of the train.
     */
    private final int number;
    /**
     * Schedule entries that this train respects.
     */
    private final List<ScheduleEntry> scheduleEntries;
    private ScheduleEntry start,end;

    public TrainClass(List<ScheduleEntry> entries , int number) {
        this.number = number;
        scheduleEntries = new DoubleList<>();
        fillEntries(entries);
    }

    /**
     * Fills the list with entries (station-time pair) of the schedule.
     * @param entries Entries of the schedule.
     */
    private void fillEntries(List<ScheduleEntry> entries) {
        for(int i = 0; i < entries.size(); i++) scheduleEntries.addLast(entries.get(i));
        start = scheduleEntries.get(0);
        end = scheduleEntries.get(entries.size()-1);
    }

    @Override
    public Station getDepartureStation() {
        return start.station();
    }

    @Override
    public int getNumber() {
        return number;
    }

    @Override
    public Iterator<ScheduleEntry> listScheduleEntries() {
        return scheduleEntries.iterator();
    }

    @Override
    public int compareTo(Train o) {
        return getNumber() - o.getNumber();
    }

    @Override
    public ScheduleEntry getStart() {
        return start;
    }

    @Override
    public ScheduleEntry getEnd() {
        return end;
    }
}
