package system;

import system.time.Time;
import system.train.Train;

import java.io.Serializable;

public interface PassingTrain extends Serializable, Comparable<PassingTrain> {
    /**
     * @return Time associated.
     */
    Time time();

    /**
     * @return Train associated.
     */
    Train train();
}
